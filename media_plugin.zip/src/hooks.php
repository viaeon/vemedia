<?php

namespace Vemedia;
use Vemedia\MediaHandler;
use Vemedia\MediaProxy;
use Vemedia\ImageLocalizer;

add_action('wp_ajax_test_storage_connection', [MediaHandler::class, 'test_storage_connection']);

MediaProxy::init();

if (MediaHandler::config('switch') == 'enable') {
    add_action('wp_ajax_vemedia_upload_one', [MediaHandler::class, 'replaced_one']);
    add_filter('attachment_fields_to_edit', [MediaHandler::class, 'attachment_editor'], 10, 2);
    add_action('delete_attachment', [MediaHandler::class, 'media_del_handle'], 10, 2);
    add_action('add_attachment', [MediaHandler::class, 'add_attachment']);
    add_filter('wp_generate_attachment_metadata', [MediaHandler::class, 'generate_attachment_metadata'], 10, 3);
    add_filter('wp_get_attachment_url', [MediaHandler::class, 'filterAttachmentUrl'], 10, 2);
    add_filter('wp_get_attachment_image_src', [MediaHandler::class, 'filterAttachmentImageSrc'], 10, 4);
    add_filter('wp_calculate_image_srcset', [MediaHandler::class, 'filterImageSrcset'], 10, 5);
    add_filter('wp_get_attachment_link', [MediaHandler::class, 'filterAttachmentLink'], 10, 6);
    add_filter('wp_attachments_s3_url', [MediaHandler::class, 'filterAttachmentsUrl'], 10, 2);

    add_filter('media_send_to_editor', [MediaHandler::class, 'filterMediaSendToEditor'], 10, 3);

    ImageLocalizer::init();
}