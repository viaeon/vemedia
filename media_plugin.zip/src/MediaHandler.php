<?php

namespace Vemedia;

use Vemedia\Plugin;
use Vemedia\Utils;
use Vemedia\S3Storage;
use Vemedia\WebDAVStorage;
use Vemedia\FTPStorage;

class MediaHandler extends Plugin
{
    private static $configInstance = null;

    private static function getConfigInstance()
    {
        if (self::$configInstance === null) {
            self::$configInstance = new self();
        }
        return self::$configInstance;
    }

    public static function config($key)
    {
        $instance = self::getConfigInstance();
        switch ($key) {
            case 'switch':
                return $instance->storage_switch;
            case 'storage_type':
                return $instance->storage_type;
            case 's3_endpoint':
                return $instance->s3_endpoint;
            case 's3_access_key':
                return $instance->s3_access_key;
            case 's3_secret_key':
                return $instance->s3_secret_key;
            case 's3_bucket':
                return $instance->s3_bucket;
            case 's3_region':
                return $instance->s3_region;
            case 's3_path_style':
                return $instance->s3_path_style;
            case 's3_custom_url':
                return $instance->s3_custom_url;
            case 'webdav_endpoint':
                return $instance->webdav_endpoint;
            case 'webdav_username':
                return $instance->webdav_username;
            case 'webdav_password':
                return $instance->webdav_password;
            case 'webdav_path':
                return $instance->webdav_path;
            case 'webdav_custom_url':
                return $instance->webdav_custom_url;
            case 'ftp_host':
                return $instance->ftp_host;
            case 'ftp_port':
                return $instance->ftp_port;
            case 'ftp_username':
                return $instance->ftp_username;
            case 'ftp_password':
                return $instance->ftp_password;
            case 'ftp_path':
                return $instance->ftp_path;
            case 'ftp_passive':
                return $instance->ftp_passive;
            case 'ftp_ssl':
                return $instance->ftp_ssl;
            case 'ftp_custom_url':
                return $instance->ftp_custom_url;
            default:
                return null;
        }
    }

    private static function isConfigured()
    {
        $storageType = self::config('storage_type');

        if ($storageType === 's3') {
            return !empty(self::config('s3_endpoint'))
                && !empty(self::config('s3_access_key'))
                && !empty(self::config('s3_secret_key'))
                && !empty(self::config('s3_bucket'));
        } elseif ($storageType === 'webdav') {
            return !empty(self::config('webdav_endpoint'));
        } elseif ($storageType === 'ftp') {
            return !empty(self::config('ftp_host'));
        }

        return false;
    }

    public static function getStorageClass()
    {
        $storageType = self::config('storage_type');
        $map = [
            's3' => S3Storage::class,
            'webdav' => WebDAVStorage::class,
            'ftp' => FTPStorage::class,
        ];
        return $map[$storageType] ?? null;
    }

    private static function buildCloudKey($dir, $filename)
    {
        if ($dir === '.' || $dir === '') {
            return $filename;
        }
        return $dir . '/' . $filename;
    }

    private static function buildThumbFilepath($basedir, $dir, $filename)
    {
        if ($dir === '.' || $dir === '') {
            return $basedir . '/' . $filename;
        }
        return $basedir . '/' . $dir . '/' . $filename;
    }

    public static function menu()
    {
        return add_menu_page(
            "VeMedia 设置",
            "VeMedia 设置",
            'manage_options',
            "vemedia_settings",
            'vemedia_display',
            'dashicons-cloud-upload',
            100
        );
    }

    public static function plugin_settings_link($links)
    {
        $settings_link = '<a href="' . admin_url('admin.php?page=vemedia_settings') . '">设置</a>';
        array_unshift($links, $settings_link);
        return $links;
    }

    public static function add_attachment($post_id)
    {
        Utils::writeLog('add_attachment 被调用, post_id=' . $post_id);

        if (!self::isConfigured()) {
            Utils::writeLog('存储配置不完整，跳过');
            return;
        }

        update_post_meta($post_id, '_vemedia_uploaded', '1');
        Utils::writeLog('已标记为待上传，等待 generate_attachment_metadata 处理');
    }

    public static function generate_attachment_metadata($meta, $post_id, $context)
    {
        Utils::writeLog('generate_attachment_metadata 被调用, context=' . $context);

        if ($context === 'update') {
            return $meta;
        }

        if (!get_post_meta($post_id, '_vemedia_uploaded', true)) {
            return $meta;
        }

        $uploadDir = wp_upload_dir();

        if (!empty($meta['sizes']) && is_array($meta['sizes'])) {
            $dir = dirname($meta['file']);
            $storageClass = self::getStorageClass();
            if (!$storageClass) {
                return $meta;
            }

            foreach ($meta['sizes'] as $size => $value) {
                if (empty($value['file'])) {
                    continue;
                }

                $filepath = self::buildThumbFilepath($uploadDir['basedir'], $dir, $value['file']);
                if (!file_exists($filepath)) {
                    Utils::writeLog('缩略图文件不存在: ' . $filepath);
                    continue;
                }

                $cloudKey = self::buildCloudKey($dir, $value['file']);
                Utils::writeLog('缩略图上传到云, cloudKey=' . $cloudKey);

                try {
                    $result = $storageClass::upload($filepath, $cloudKey);
                    if (!empty($result['status'])) {
                        Utils::writeLog('缩略图上传成功: ' . $cloudKey);
                    } else {
                        Utils::writeLog('缩略图上传失败: ' . json_encode($result));
                    }
                } catch (\Exception $e) {
                    Utils::writeLog('缩略图上传异常: ' . $e->getMessage());
                }
            }
        }

        Utils::writeLog('检查主文件, meta[file]=' . ($meta['file'] ?? 'null'));

        if (!empty($meta['file'])) {
            $mainFile = $uploadDir['basedir'] . '/' . $meta['file'];
            Utils::writeLog('主文件路径: ' . $mainFile . ', 存在=' . (file_exists($mainFile) ? 'yes' : 'no'));

            if (file_exists($mainFile)) {
                $mainCloudKey = $meta['file'];
                Utils::writeLog('上传主文件(元数据中的file): ' . $mainCloudKey);

                $storageClass = self::getStorageClass();
                if ($storageClass) {
                    try {
                        $result = $storageClass::upload($mainFile, $mainCloudKey);
                        if (!empty($result['status'])) {
                            Utils::writeLog('主文件上传成功: ' . $mainCloudKey);
                            update_post_meta($post_id, '_vemedia_cloud_key', $mainCloudKey);
                        } else {
                            Utils::writeLog('主文件上传失败: ' . json_encode($result));
                        }
                    } catch (\Exception $e) {
                        Utils::writeLog('主文件上传异常: ' . $e->getMessage());
                    }
                }
            } else {
                Utils::writeLog('主文件不存在，跳过上传');
            }
        } else {
            Utils::writeLog('meta[file] 为空，跳过主文件上传');
        }

        self::deleteLocalFiles($post_id, $meta);

        return $meta;
    }

    private static function deleteLocalFiles($post_id, $meta)
    {
        $uploadDir = wp_upload_dir();

        $originalFile = get_attached_file($post_id);
        if ($originalFile && file_exists($originalFile)) {
            @unlink($originalFile);
            Utils::writeLog('已删除本地原始文件: ' . $originalFile);
        }

        if (!empty($meta['sizes']) && is_array($meta['sizes'])) {
            $dir = dirname($meta['file']);
            foreach ($meta['sizes'] as $size => $value) {
                if (empty($value['file'])) {
                    continue;
                }
                $filepath = self::buildThumbFilepath($uploadDir['basedir'], $dir, $value['file']);
                if (file_exists($filepath)) {
                    @unlink($filepath);
                    Utils::writeLog('已删除本地缩略图: ' . $filepath);
                }
            }
        }
    }

    public static function media_del_handle($post_id, $post)
    {
        $meta = wp_get_attachment_metadata($post_id);
        if (!$meta) {
            return;
        }

        $storageClass = self::getStorageClass();
        if (!$storageClass) {
            return;
        }

        $oldKey = $meta['key'] ?? '';
        if (!empty($oldKey)) {
            $storageClass::delete($oldKey);
            Utils::writeLog('已删除云端文件(旧格式): ' . $oldKey);
        }

        if (!empty($meta['file'])) {
            $cloudKey = $meta['file'];
            $storageClass::delete($cloudKey);
            Utils::writeLog('已删除云端原始文件: ' . $cloudKey);
        }

        if (!empty($meta['sizes']) && is_array($meta['sizes'])) {
            $dir = dirname($meta['file']);
            foreach ($meta['sizes'] as $size => $value) {
                $sizeKey = $value['key'] ?? '';
                if (!empty($sizeKey)) {
                    $storageClass::delete($sizeKey);
                    Utils::writeLog('已删除云端缩略图(旧格式): ' . $sizeKey);
                }

                if (!empty($value['file'])) {
                    $cloudKey = self::buildCloudKey($dir, $value['file']);
                    $storageClass::delete($cloudKey);
                    Utils::writeLog('已删除云端缩略图: ' . $cloudKey);
                }
            }
        }

        delete_post_meta($post_id, '_vemedia_uploaded');
    }

    public static function attachment_editor($form_fields, $post)
    {
        $post_id = $post->ID;
        $uploaded = get_post_meta($post_id, '_vemedia_uploaded', true);
        $label = $uploaded ? esc_html__("已存储至云端", "vemedia") : esc_html__("一键替换", "vemedia");
        $disabled = $uploaded ? 'disabled' : '';
        $form_fields["upload-to-vemedia"] = [
            "label" => esc_html__("云端存储", "vemedia"),
            "input" => "html",
            "html" => '<script>var vemedia_js_flag="page";var vemedia_ajax_url="' . admin_url('admin-ajax.php') . '";var post_id="' . $post_id . '";</script>' . "<a class='button-secondary' id='vemedia-upload-one' href=\"javascript:;\" $disabled>" . $label . "</a>" . '<script src="' . plugins_url('../static/post.js', __FILE__) . '"></script>',
            "helps" => esc_html__("将媒体文件上传到云端存储并删除本地副本。", "vemedia")
        ];
        return $form_fields;
    }

    public static function update_to_cloud($post_id)
    {
        $meta = wp_get_attachment_metadata($post_id);
        if (!$meta) {
            Utils::writeLog('update_to_cloud: 无法获取附件元数据');
            return;
        }

        if (get_post_meta($post_id, '_vemedia_uploaded', true)) {
            Utils::writeLog('update_to_cloud: 文件已上传至云端');
            return;
        }

        $storageClass = self::getStorageClass();
        if (!$storageClass) {
            return;
        }

        $uploadDir = wp_upload_dir();

        $originalFile = get_attached_file($post_id);
        if ($originalFile && file_exists($originalFile)) {
            $cloudKey = StorageInterface::getCloudKey($originalFile);
            Utils::writeLog('一键替换: 上传原始文件, cloudKey=' . $cloudKey);
            $result = $storageClass::upload($originalFile, $cloudKey);
            if (!empty($result['status'])) {
                Utils::writeLog('一键替换: 原始文件上传成功');
                update_post_meta($post_id, '_vemedia_cloud_key', $cloudKey);
            } else {
                Utils::writeLog('一键替换: 原始文件上传失败: ' . json_encode($result));
                return;
            }
        }

        if (!empty($meta['sizes']) && is_array($meta['sizes'])) {
            $dir = dirname($meta['file']);
            foreach ($meta['sizes'] as $size => $value) {
                if (empty($value['file'])) {
                    continue;
                }
                $filepath = self::buildThumbFilepath($uploadDir['basedir'], $dir, $value['file']);
                if (file_exists($filepath)) {
                    $cloudKey = self::buildCloudKey($dir, $value['file']);
                    Utils::writeLog('一键替换: 上传缩略图, cloudKey=' . $cloudKey);
                    $storageClass::upload($filepath, $cloudKey);
                }
            }
        }

        update_post_meta($post_id, '_vemedia_uploaded', '1');
        self::deleteLocalFiles($post_id, $meta);
        Utils::writeLog('一键替换: 完成');
    }

    public static function replaced_one()
    {
        $post_id = intval($_POST['post_id']);
        self::update_to_cloud($post_id);
        wp_send_json_success(['message' => '上传完成']);
    }

    public static function test_storage_connection()
    {
        $storage_type = sanitize_text_field($_POST['storage_type']);
        $result = ['status' => false, 'message' => '未知存储类型'];

        $temp_setting = unserialize(get_option('vemedia_setting'));

        if ($storage_type === 's3') {
            $temp_setting['s3_endpoint'] = sanitize_text_field($_POST['s3_endpoint']);
            $temp_setting['s3_access_key'] = sanitize_text_field($_POST['s3_access_key']);
            $temp_setting['s3_secret_key'] = sanitize_text_field($_POST['s3_secret_key']);
            $temp_setting['s3_bucket'] = sanitize_text_field($_POST['s3_bucket']);
            $temp_setting['s3_region'] = sanitize_text_field($_POST['s3_region']);
            $temp_setting['s3_path_style'] = sanitize_text_field($_POST['s3_path_style']);
            update_option('vemedia_setting', serialize($temp_setting));
            self::$configInstance = null;
            $result = S3Storage::testConnection();
        } elseif ($storage_type === 'webdav') {
            $temp_setting['webdav_endpoint'] = sanitize_text_field($_POST['webdav_endpoint']);
            $temp_setting['webdav_username'] = sanitize_text_field($_POST['webdav_username']);
            $temp_setting['webdav_password'] = sanitize_text_field($_POST['webdav_password']);
            $temp_setting['webdav_path'] = sanitize_text_field($_POST['webdav_path']);
            update_option('vemedia_setting', serialize($temp_setting));
            self::$configInstance = null;
            $result = WebDAVStorage::testConnection();
        } elseif ($storage_type === 'ftp') {
            $temp_setting['ftp_host'] = sanitize_text_field($_POST['ftp_host']);
            $temp_setting['ftp_port'] = sanitize_text_field($_POST['ftp_port']);
            $temp_setting['ftp_username'] = sanitize_text_field($_POST['ftp_username']);
            $temp_setting['ftp_password'] = sanitize_text_field($_POST['ftp_password']);
            $temp_setting['ftp_path'] = sanitize_text_field($_POST['ftp_path']);
            $temp_setting['ftp_passive'] = sanitize_text_field($_POST['ftp_passive']);
            $temp_setting['ftp_ssl'] = sanitize_text_field($_POST['ftp_ssl']);
            update_option('vemedia_setting', serialize($temp_setting));
            self::$configInstance = null;
            $result = FTPStorage::testConnection();
        }

        if (ob_get_length()) ob_clean();
        echo json_encode($result);
        wp_die();
    }

    public static function filterAttachmentUrl($url, $post_id)
    {
        if (!MediaProxy::isCloudAttachment($post_id)) {
            return $url;
        }

        $cloudKey = get_post_meta($post_id, '_vemedia_cloud_key', true);
        if (empty($cloudKey)) {
            $filepath = get_attached_file($post_id);
            if ($filepath && file_exists($filepath)) {
                $cloudKey = StorageInterface::getCloudKey($filepath);
            } else {
                $meta = wp_get_attachment_metadata($post_id);
                $cloudKey = $meta['file'] ?? '';
            }
        }

        if (empty($cloudKey)) {
            return $url;
        }

        return MediaProxy::getProxyUrl($cloudKey);
    }

    public static function filterAttachmentImageSrc($image, $attachment_id, $size, $icon)
    {
        if (!$image) {
            return $image;
        }

        $isCloud = MediaProxy::isCloudAttachment($attachment_id);
        Utils::writeLog("filterAttachmentImageSrc called: post_id=$attachment_id, isCloud=$isCloud, size=" . (is_string($size) ? $size : 'unknown'));

        if (!$isCloud) {
            return $image;
        }

        $meta = wp_get_attachment_metadata($attachment_id);
        Utils::writeLog("filterAttachmentImageSrc: meta=" . json_encode($meta));

        if (!$meta || empty($meta['file'])) {
            return $image;
        }

        $dir = dirname($meta['file']);
        $cloudKey = null;

        if ($size === 'full') {
            $cloudKey = $meta['file'];
        } elseif (is_string($size) && !empty($meta['sizes'][$size])) {
            $cloudKey = self::buildCloudKey($dir, $meta['sizes'][$size]['file']);
        } else {
            $cloudKey = $meta['file'];
        }

        Utils::writeLog("filterAttachmentImageSrc: cloudKey=$cloudKey, dir=$dir");

        if ($cloudKey) {
            $image[0] = MediaProxy::getProxyUrl($cloudKey);
            Utils::writeLog("filterAttachmentImageSrc: replaced with " . $image[0]);
        }

        return $image;
    }

    public static function filterAttachmentMetadata($data, $post_id)
    {
        if (!$data || !MediaProxy::isCloudAttachment($post_id)) {
            return $data;
        }

        return $data;
    }

    public static function filterAttachmentLink($link, $post, $size)
    {
        if (!MediaProxy::isCloudAttachment($post->ID)) {
            return $link;
        }

        $meta = wp_get_attachment_metadata($post->ID);
        if (!$meta || empty($meta['file'])) {
            return $link;
        }

        $cloudKey = $meta['file'];
        $proxyUrl = MediaProxy::getProxyUrl($cloudKey);
        return $proxyUrl;
    }

    public static function filterImageSrcset($sources, $size_array, $image_src, $image_meta, $attachment_id)
    {
        if (!MediaProxy::isCloudAttachment($attachment_id)) {
            return $sources;
        }

        if (!$sources || empty($image_meta['sizes'])) {
            return $sources;
        }

        $dir = dirname($image_meta['file']);
        $cloudKey = $image_meta['file'];

        foreach ($sources as $width => $source) {
            if (isset($image_meta['sizes'])) {
                foreach ($image_meta['sizes'] as $size_name => $size_data) {
                    if (isset($size_data['width']) && $size_data['width'] == $width) {
                        $thumbKey = self::buildCloudKey($dir, $size_data['file']);
                        $sources[$width]['url'] = MediaProxy::getProxyUrl($thumbKey);
                        break;
                    }
                }
            }
        }

        return $sources;
    }

    public static function filterAttachmentsUrl($url, $attachment_id) {
        if (!MediaProxy::isCloudAttachment($attachment_id)) {
            return $url;
        }
        $meta = wp_get_attachmen_metadata($attachment_id);
        if (!$meta || empty($meta['file'])) {
            return $url;
        }
        return MediaProxy::getProxyUrl($meta['file']);
    }

    public static function filterMediaSendToEditor($html, $attachment_id, $data) {
        if (!MediaProxy::isCloudAttachment($attachment_id)) {
            return $html;
        }
        $meta = wp_get_attachment_metadata($attachment_id);
        if (!$meta || empty($meta['file'])) {
            return $html;
        }
        $proxyUrl = MediaProxy::getProxyUrl($meta['file']);
        $html = preg_replace('/src="[^"]+"/', 'src="' . esc_url($proxyUrl) . '"', $html);
        $html = preg_replace('/href="[^"]+"/', 'href="' . esc_url($proxyUrl) . '"', $html);
        return $html;
    }
}
