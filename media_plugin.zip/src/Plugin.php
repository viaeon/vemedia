<?php

namespace Vemedia;

abstract class Plugin
{
    public $storage_switch;
    public $storage_type;

    public $s3_endpoint;
    public $s3_access_key;
    public $s3_secret_key;
    public $s3_bucket;
    public $s3_region;
    public $s3_path_style;
    public $s3_custom_url;

    public $webdav_endpoint;
    public $webdav_username;
    public $webdav_password;
    public $webdav_path;
    public $webdav_custom_url;

    public $ftp_host;
    public $ftp_port;
    public $ftp_username;
    public $ftp_password;
    public $ftp_path;
    public $ftp_passive;
    public $ftp_ssl;
    public $ftp_custom_url;

    protected static $instance = null;

    public function __construct()
    {
        $setting = get_option('vemedia_setting');
        if ($setting) {
            $setting = @unserialize($setting);
        }
        
        if (!is_array($setting)) {
            $setting = [];
        }

        $this->storage_switch = $setting['switch'] ?? 'disable';
        $this->storage_type = $setting['storage_type'] ?? 's3';

        $this->s3_endpoint = $setting['s3_endpoint'] ?? '';
        $this->s3_access_key = $setting['s3_access_key'] ?? '';
        $this->s3_secret_key = $setting['s3_secret_key'] ?? '';
        $this->s3_bucket = $setting['s3_bucket'] ?? '';
        $this->s3_region = $setting['s3_region'] ?? 'us-east-1';
        $this->s3_path_style = $setting['s3_path_style'] ?? 'no';
        $this->s3_custom_url = $setting['s3_custom_url'] ?? '';

        $this->webdav_endpoint = $setting['webdav_endpoint'] ?? '';
        $this->webdav_username = $setting['webdav_username'] ?? '';
        $this->webdav_password = $setting['webdav_password'] ?? '';
        $this->webdav_path = $setting['webdav_path'] ?? '/';
        $this->webdav_custom_url = $setting['webdav_custom_url'] ?? '';

        $this->ftp_host = $setting['ftp_host'] ?? '';
        $this->ftp_port = $setting['ftp_port'] ?? 21;
        $this->ftp_username = $setting['ftp_username'] ?? '';
        $this->ftp_password = $setting['ftp_password'] ?? '';
        $this->ftp_path = $setting['ftp_path'] ?? '/';
        $this->ftp_passive = $setting['ftp_passive'] ?? 'yes';
        $this->ftp_ssl = $setting['ftp_ssl'] ?? 'no';
        $this->ftp_custom_url = $setting['ftp_custom_url'] ?? '';
    }

    public static function getPluginDir()
    {
        return defined('VEMEDIA_PLUGIN_DIR') ? VEMEDIA_PLUGIN_DIR : WP_PLUGIN_DIR . '/vemedia/';
    }

    public static function getLogDir()
    {
        return self::getPluginDir() . 'logs/';
    }
}
